import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import logo from "@/assets/sml-logo.png.asset.json";

type Status = "Loading" | "In-Transit" | "Unloading" | "Paid";

type Trip = {
  id: string;
  truck: string;
  driver?: string;
  party: string;
  from: string;
  to: string;
  amount: number;
  status: Status;
  progress: number;
  eta: string;
  alert?: string;
  balance: number;
  commission: number;
  advanceReceived: number; // from party (transport company) to us
  advancePaid: number;     // from us to truck / driver
  weight?: number; // kg
  createdAt: number;
};

type TruckMeta = {
  truck: string;
  driver?: string;
  tires: number;
};

const INITIAL_TRIPS: Trip[] = [
  { id: "LD-2841", truck: "GJ01-AB-2245", driver: "Ramesh", party: "Patel Logistics", from: "Ahmedabad", to: "Mumbai", amount: 42500, status: "In-Transit", progress: 64, eta: "5h", balance: 25000, commission: 2125, advanceReceived: 17500, advancePaid: 15000, weight: 9000, createdAt: Date.now() - 5 * 86400000 },
  { id: "LD-2839", truck: "MH04-CK-9921", driver: "Suresh", party: "Sharma Traders", from: "Surat", to: "Delhi", amount: 78200, status: "Loading", progress: 8, eta: "12h", balance: 60000, commission: 3910, advanceReceived: 18200, advancePaid: 16000, weight: 15000, createdAt: Date.now() - 4 * 86400000 },
  { id: "LD-2835", truck: "RJ14-DL-1148", driver: "Mahesh", party: "Mehta Group", from: "Jaipur", to: "Pune", amount: 56000, status: "Unloading", progress: 96, eta: "1h", alert: "POD Pending · 3h overdue", balance: 40000, commission: 2800, advanceReceived: 16000, advancePaid: 14000, weight: 12000, createdAt: Date.now() - 3 * 86400000 },
  { id: "LD-2830", truck: "DL01-PQ-7763", driver: "Vinod", party: "Khanna Movers", from: "Delhi", to: "Lucknow", amount: 31800, status: "Paid", progress: 100, eta: "—", balance: 0, commission: 1590, advanceReceived: 10000, advancePaid: 9000, weight: 8000, createdAt: Date.now() - 10 * 86400000 },
];

const INITIAL_TRUCKS: TruckMeta[] = [
  { truck: "GJ01-AB-2245", driver: "Ramesh", tires: 10 },
  { truck: "MH04-CK-9921", driver: "Suresh", tires: 12 },
  { truck: "RJ14-DL-1148", driver: "Mahesh", tires: 10 },
  { truck: "DL01-PQ-7763", driver: "Vinod", tires: 6 },
];

const FILTERS: (Status | "All")[] = ["All", "Loading", "In-Transit", "Unloading", "Paid"];
type Tab = "Home" | "Loads" | "Khata" | "Vahan";

const inr = (n: number) =>
  "₹ " + new Intl.NumberFormat("en-IN", { maximumFractionDigits: 0 }).format(n);

const kg = (n: number) =>
  n >= 1000 ? `${(n / 1000).toFixed(1)} T` : `${n} kg`;

// ----- persistence -----
const LS_TRIPS = "sml.trips.v1";
const LS_TRUCKS = "sml.trucks.v1";

function loadLS<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Shree Mewad Logistics — Smart Load Board" },
      { name: "description", content: "Live trip board: track loads, parties (Khata), trucks (Vahan) and payments." },
      { property: "og:title", content: "Shree Mewad Logistics — Smart Load Board" },
      { property: "og:description", content: "Live trip board: track loads, parties (Khata), trucks (Vahan) and payments." },
    ],
  }),
  component: App,
});

function App() {
  const [hydrated, setHydrated] = useState(false);
  const [trips, setTrips] = useState<Trip[]>(INITIAL_TRIPS);
  const [trucks, setTrucks] = useState<TruckMeta[]>(INITIAL_TRUCKS);
  const [tab, setTab] = useState<Tab>("Loads");
  const [openId, setOpenId] = useState<string | null>(null);
  const [showNew, setShowNew] = useState(false);

  // Hydrate from localStorage
  useEffect(() => {
    setTrips(loadLS(LS_TRIPS, INITIAL_TRIPS));
    setTrucks(loadLS(LS_TRUCKS, INITIAL_TRUCKS));
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) window.localStorage.setItem(LS_TRIPS, JSON.stringify(trips));
  }, [trips, hydrated]);
  useEffect(() => {
    if (hydrated) window.localStorage.setItem(LS_TRUCKS, JSON.stringify(trucks));
  }, [trucks, hydrated]);

  const openTrip = trips.find((t) => t.id === openId) ?? null;

  const addTrip = (t: Trip) => {
    setTrips((prev) => [t, ...prev]);
    // Register/refresh truck meta
    setTrucks((prev) => {
      const idx = prev.findIndex((x) => x.truck === t.truck);
      if (idx === -1) {
        return [...prev, { truck: t.truck, driver: t.driver, tires: 6 }];
      }
      const copy = [...prev];
      copy[idx] = { ...copy[idx], driver: t.driver ?? copy[idx].driver };
      return copy;
    });
    setShowNew(false);
  };

  const updateTruck = (truck: string, patch: Partial<TruckMeta>) => {
    setTrucks((prev) => prev.map((x) => (x.truck === truck ? { ...x, ...patch } : x)));
  };

  return (
    <div className="min-h-screen bg-[var(--app-bg)] pb-28">
      <Header />

      {tab === "Loads" && (
        <LoadsView
          trips={trips}
          onOpen={setOpenId}
          onNew={() => setShowNew(true)}
        />
      )}
      {tab === "Home" && <HomeView trips={trips} trucks={trucks} onNew={() => setShowNew(true)} />}
      {tab === "Khata" && <KhataView trips={trips} />}
      {tab === "Vahan" && <VahanView trips={trips} trucks={trucks} onUpdateTruck={updateTruck} />}

      <BottomNav tab={tab} onTab={setTab} />
      <LoadDetailDrawer trip={openTrip} onClose={() => setOpenId(null)} />
      <NewTripDrawer
        open={showNew}
        existingIds={trips.map((t) => t.id)}
        trucks={trucks}
        onClose={() => setShowNew(false)}
        onCreate={addTrip}
      />
    </div>
  );
}

// ============ Header ============
function Header() {
  return (
    <header className="px-5 pt-6">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <img src={logo.url} alt="Shree Mewad Logistics" className="h-11 w-11 rounded-full" />
          <div>
            <h1 className="text-base font-bold tracking-tight text-foreground leading-tight">
              Shree Mewad Logistics
            </h1>
            <p className="text-xs text-muted-foreground">Smart Load Board</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <LangPill />
        </div>
      </div>
    </header>
  );
}

// ============ Home ============
function HomeView({ trips, trucks, onNew }: { trips: Trip[]; trucks: TruckMeta[]; onNew: () => void }) {
  const active = trips.filter((t) => t.status !== "Paid").length;
  const receivable = trips.reduce((s, t) => s + t.balance, 0);
  const commissionEarned = trips.reduce((s, t) => s + t.commission, 0);

  return (
    <section className="mt-6 px-5">
      <h2 className="text-xl font-bold text-foreground">Overview</h2>
      <p className="text-xs text-muted-foreground">Business at a glance</p>

      <div className="mt-4 grid grid-cols-2 gap-3">
        <Stat label="Active trips" value={String(active)} />
        <Stat label="Trucks" value={String(trucks.length)} />
        <Stat label="Receivable" value={inr(receivable)} />
        <Stat label="Commission" value={inr(commissionEarned)} />
      </div>

      <button
        onClick={onNew}
        className="mt-5 w-full rounded-2xl bg-primary py-3 text-sm font-semibold text-primary-foreground shadow-sm"
      >
        + Add New Trip
      </button>
    </section>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="mt-1 text-lg font-bold text-foreground">{value}</div>
    </div>
  );
}

// ============ Loads ============
function LoadsView({
  trips,
  onOpen,
  onNew,
}: {
  trips: Trip[];
  onOpen: (id: string) => void;
  onNew: () => void;
}) {
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("All");
  const visible = useMemo(
    () => (filter === "All" ? trips : trips.filter((t) => t.status === filter)),
    [filter, trips],
  );

  return (
    <section className="mt-6 px-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-foreground">Active Loads</h2>
          <p className="text-xs text-muted-foreground">{trips.length} trips live</p>
        </div>
        <button
          onClick={onNew}
          className="inline-flex h-9 items-center gap-1 rounded-full bg-primary px-4 text-sm font-semibold text-primary-foreground shadow-sm"
        >
          + New
        </button>
      </div>

      <div className="mt-4 flex gap-2 overflow-x-auto pb-1 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {FILTERS.map((f) => {
          const active = f === filter;
          return (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={
                "shrink-0 rounded-full px-4 py-1.5 text-sm font-medium transition-colors " +
                (active
                  ? "bg-foreground text-background"
                  : "border border-border bg-card text-muted-foreground hover:text-foreground")
              }
            >
              {f}
            </button>
          );
        })}
      </div>

      <div className="mt-4 space-y-4">
        {visible.length === 0 ? (
          <EmptyState title="No trips" hint='Tap "+ New" to add one.' />
        ) : (
          visible.map((t) => <TripCard key={t.id} trip={t} onOpen={() => onOpen(t.id)} />)
        )}
      </div>
    </section>
  );
}

function TripCard({ trip, onOpen }: { trip: Trip; onOpen: () => void }) {
  return (
    <article
      onClick={onOpen}
      className="cursor-pointer rounded-2xl border border-border bg-card p-4 shadow-[0_1px_2px_rgba(15,23,42,0.04)] transition-shadow hover:shadow-md"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-muted text-muted-foreground">🚚</div>
          <div>
            <div className="text-sm font-bold text-foreground">{trip.truck}</div>
            <div className="text-xs text-muted-foreground">
              {trip.id} · {trip.party}
            </div>
          </div>
        </div>
        <StatusBadge status={trip.status} />
      </div>

      <div className="mt-3 flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
          <Pin className="text-primary" /> {trip.from}
          <span className="text-muted-foreground">→</span>
          <Pin className="text-emerald-500" /> {trip.to}
        </div>
        <div className="text-sm font-bold text-foreground">{inr(trip.amount)}</div>
      </div>

      <div className="mt-3">
        <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
          <div
            className="h-full rounded-full bg-gradient-to-r from-primary to-emerald-500"
            style={{ width: `${trip.progress}%` }}
          />
        </div>
        <div className="mt-1.5 flex items-center justify-between text-xs text-muted-foreground">
          <span>{trip.progress}% · {trip.weight ? kg(trip.weight) : "—"}</span>
          <span>ETA: {trip.eta}</span>
        </div>
      </div>

      {trip.alert ? (
        <div className="mt-3 flex items-center gap-2 rounded-lg border border-destructive/20 bg-destructive/10 px-3 py-2 text-xs font-medium text-destructive">
          ⚠ {trip.alert}
        </div>
      ) : null}
    </article>
  );
}

// ============ Khata ============
type DateRange = "All" | "7d" | "30d" | "This month" | "Custom";
const DATE_RANGES: DateRange[] = ["All", "7d", "30d", "This month", "Custom"];

function KhataView({ trips }: { trips: Trip[] }) {
  const [query, setQuery] = useState("");
  const [range, setRange] = useState<DateRange>("All");
  const [customFrom, setCustomFrom] = useState("");
  const [customTo, setCustomTo] = useState("");

  const bounds = useMemo(() => {
    const now = new Date();
    if (range === "7d") return { from: now.getTime() - 7 * 86400000, to: Infinity };
    if (range === "30d") return { from: now.getTime() - 30 * 86400000, to: Infinity };
    if (range === "This month") {
      const first = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
      return { from: first, to: Infinity };
    }
    if (range === "Custom") {
      const f = customFrom ? new Date(customFrom).getTime() : -Infinity;
      const tRaw = customTo ? new Date(customTo).getTime() : Infinity;
      const t = Number.isFinite(tRaw) ? tRaw + 86400000 - 1 : tRaw;
      return { from: f, to: t };
    }
    return { from: -Infinity, to: Infinity };
  }, [range, customFrom, customTo]);

  const filteredTrips = useMemo(
    () => trips.filter((t) => t.createdAt >= bounds.from && t.createdAt <= bounds.to),
    [trips, bounds],
  );

  const parties = useMemo(() => {
    const map = new Map<string, { name: string; trips: number; amount: number; balance: number; commission: number; advanceReceived: number; advancePaid: number }>();
    for (const t of filteredTrips) {
      const p = map.get(t.party) ?? { name: t.party, trips: 0, amount: 0, balance: 0, commission: 0, advanceReceived: 0, advancePaid: 0 };
      p.trips += 1;
      p.amount += t.amount;
      p.balance += t.balance;
      p.commission += t.commission;
      p.advanceReceived += t.advanceReceived;
      p.advancePaid += t.advancePaid;
      map.set(t.party, p);
    }
    const q = query.trim().toLowerCase();
    let list = Array.from(map.values());
    if (q) list = list.filter((p) => p.name.toLowerCase().includes(q));
    return list.sort((a, b) => b.balance - a.balance);
  }, [filteredTrips, query]);

  const totalReceivable = parties.reduce((s, p) => s + p.balance, 0);

  return (
    <section className="mt-6 px-5">
      <h2 className="text-xl font-bold text-foreground">Khata</h2>
      <p className="text-xs text-muted-foreground">
        Company (party) ledger · {parties.length} {parties.length === 1 ? "party" : "parties"}
      </p>

      <div className="mt-4 rounded-2xl bg-foreground p-4 text-background">
        <div className="flex items-center justify-between">
          <span className="text-sm opacity-80">Total Receivable</span>
          <span className="text-xl font-bold">{inr(totalReceivable)}</span>
        </div>
        <div className="mt-1 text-xs opacity-70">
          {range === "All" ? "All time" : range === "Custom" ? "Custom range" : `Last ${range === "This month" ? "month" : range}`}
        </div>
      </div>

      <div className="mt-4 space-y-3">
        <div className="relative">
          <span className="pointer-events-none absolute inset-y-0 left-3 flex items-center text-muted-foreground">⌕</span>
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search party name…"
            className="w-full rounded-full border border-border bg-card py-2 pl-9 pr-9 text-sm text-foreground outline-none ring-ring focus:ring-2"
          />
          {query ? (
            <button
              onClick={() => setQuery("")}
              aria-label="Clear search"
              className="absolute inset-y-0 right-3 flex items-center text-xs text-muted-foreground hover:text-foreground"
            >
              ✕
            </button>
          ) : null}
        </div>

        <div className="flex gap-2 overflow-x-auto pb-1 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {DATE_RANGES.map((r) => {
            const active = r === range;
            return (
              <button
                key={r}
                onClick={() => setRange(r)}
                className={
                  "shrink-0 rounded-full px-3 py-1.5 text-xs font-medium transition-colors " +
                  (active
                    ? "bg-foreground text-background"
                    : "border border-border bg-card text-muted-foreground hover:text-foreground")
                }
              >
                {r}
              </button>
            );
          })}
        </div>

        {range === "Custom" ? (
          <div className="grid grid-cols-2 gap-2 rounded-xl border border-border bg-card p-3">
            <label className="block">
              <span className="text-xs text-muted-foreground">From</span>
              <input
                type="date"
                value={customFrom}
                onChange={(e) => setCustomFrom(e.target.value)}
                className="mt-1 w-full rounded-lg border border-input bg-background px-2 py-1.5 text-sm text-foreground outline-none ring-ring focus:ring-2"
              />
            </label>
            <label className="block">
              <span className="text-xs text-muted-foreground">To</span>
              <input
                type="date"
                value={customTo}
                onChange={(e) => setCustomTo(e.target.value)}
                className="mt-1 w-full rounded-lg border border-input bg-background px-2 py-1.5 text-sm text-foreground outline-none ring-ring focus:ring-2"
              />
            </label>
          </div>
        ) : null}
      </div>

      <div className="mt-4 space-y-3">
        {parties.length === 0 ? (
          <EmptyState
            title={query || range !== "All" ? "No matches" : "No parties yet"}
            hint={query || range !== "All" ? "Try clearing filters or a wider date range." : "Add a trip to create a party entry."}
          />
        ) : (
          parties.map((p) => (
            <div key={p.name} className="rounded-2xl border border-border bg-card p-4">
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-sm font-bold text-foreground">{p.name}</div>
                  <div className="text-xs text-muted-foreground">{p.trips} trip{p.trips === 1 ? "" : "s"}</div>
                </div>
                <div className={"text-sm font-bold " + (p.balance > 0 ? "text-destructive" : "text-emerald-600")}>
                  {p.balance > 0 ? inr(p.balance) : "Settled"}
                </div>
              </div>
              <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                <MiniStat label="Billed" value={inr(p.amount)} />
                <MiniStat label="Pending" value={inr(p.balance)} />
                <MiniStat label="Commission" value={inr(p.commission)} />
              </div>
              <div className="mt-2 grid grid-cols-2 gap-2 text-center">
                <MiniStat label="Advance In" value={inr(p.advanceReceived)} />
                <MiniStat label="Advance Out" value={inr(p.advancePaid)} />
              </div>
            </div>
          ))
        )}
      </div>
    </section>
  );
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-muted px-2 py-2">
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="mt-0.5 text-xs font-semibold text-foreground">{value}</div>
    </div>
  );
}

// ============ Vahan ============
function VahanView({
  trips,
  trucks,
  onUpdateTruck,
}: {
  trips: Trip[];
  trucks: TruckMeta[];
  onUpdateTruck: (truck: string, patch: Partial<TruckMeta>) => void;
}) {
  const summary = useMemo(() => {
    return trucks.map((meta) => {
      const own = trips.filter((t) => t.truck === meta.truck);
      const totalWeight = own.reduce((s, t) => s + (t.weight ?? 0), 0);
      const lastTrip = own[0];
      return {
        ...meta,
        trips: own.length,
        totalWeight,
        lastRoute: lastTrip ? `${lastTrip.from} → ${lastTrip.to}` : "—",
        lastWeight: lastTrip?.weight ?? 0,
      };
    });
  }, [trips, trucks]);

  return (
    <section className="mt-6 px-5">
      <h2 className="text-xl font-bold text-foreground">Vahan</h2>
      <p className="text-xs text-muted-foreground">Trucks & drivers · {trucks.length} vehicles</p>

      <div className="mt-4 space-y-3">
        {summary.length === 0 ? (
          <EmptyState title="No trucks" hint="Add a trip to register a truck." />
        ) : (
          summary.map((s) => (
            <div key={s.truck} className="rounded-2xl border border-border bg-card p-4">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  <div className="grid h-10 w-10 place-items-center rounded-xl bg-muted">🛻</div>
                  <div>
                    <div className="text-sm font-bold text-foreground">{s.truck}</div>
                    <div className="text-xs text-muted-foreground">Driver: {s.driver || "—"}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-muted-foreground">Trips</div>
                  <div className="text-sm font-bold text-foreground">{s.trips}</div>
                </div>
              </div>

              <div className="mt-3 grid grid-cols-3 gap-2">
                <MiniStat label="Total Load" value={kg(s.totalWeight)} />
                <MiniStat label="Last Trip" value={s.lastWeight ? kg(s.lastWeight) : "—"} />
                <div className="rounded-lg bg-muted px-2 py-1">
                  <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Tires</div>
                  <input
                    type="number"
                    min={2}
                    max={22}
                    value={s.tires}
                    onChange={(e) => onUpdateTruck(s.truck, { tires: parseInt(e.target.value) || 0 })}
                    className="mt-0.5 w-full bg-transparent text-xs font-semibold text-foreground outline-none"
                  />
                </div>
              </div>

              <div className="mt-3 rounded-lg bg-[var(--app-bg)] px-3 py-2">
                <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Last route</div>
                <div className="text-xs font-medium text-foreground">{s.lastRoute}</div>
              </div>

              <div className="mt-3">
                <label className="block text-xs text-muted-foreground">Driver name</label>
                <input
                  value={s.driver ?? ""}
                  onChange={(e) => onUpdateTruck(s.truck, { driver: e.target.value })}
                  placeholder="Add driver"
                  className="mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground outline-none ring-ring focus:ring-2"
                />
              </div>
            </div>
          ))
        )}
      </div>
    </section>
  );
}

// ============ Shared UI ============
function EmptyState({ title, hint }: { title: string; hint: string }) {
  return (
    <div className="rounded-2xl border border-dashed border-border bg-card p-8 text-center">
      <div className="text-sm font-semibold text-foreground">{title}</div>
      <div className="mt-1 text-xs text-muted-foreground">{hint}</div>
    </div>
  );
}

function StatusBadge({ status }: { status: Status }) {
  const styles: Record<Status, string> = {
    Loading: "bg-amber-100 text-amber-700",
    "In-Transit": "bg-sky-100 text-sky-700",
    Unloading: "bg-slate-200 text-slate-700",
    Paid: "bg-emerald-100 text-emerald-700",
  };
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium ${styles[status]}`}>
      <span className="h-1.5 w-1.5 rounded-full bg-current" />
      {status}
    </span>
  );
}

function Pin({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={`h-4 w-4 ${className}`} fill="currentColor" aria-hidden>
      <path d="M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7Zm0 9.5A2.5 2.5 0 1 1 12 6a2.5 2.5 0 0 1 0 5.5Z" />
    </svg>
  );
}

function LangPill() {
  const langs = ["EN", "HI", "GU"];
  const [active, setActive] = useState("EN");
  return (
    <div className="flex items-center rounded-full bg-muted p-0.5 text-xs font-semibold">
      {langs.map((l) => (
        <button
          key={l}
          onClick={() => setActive(l)}
          className={"rounded-full px-2.5 py-1 " + (active === l ? "bg-foreground text-background" : "text-muted-foreground")}
        >
          {l}
        </button>
      ))}
    </div>
  );
}

function BottomNav({ tab, onTab }: { tab: Tab; onTab: (t: Tab) => void }) {
  const items: { label: Tab; icon: string }[] = [
    { label: "Home", icon: "🏠" },
    { label: "Loads", icon: "📦" },
    { label: "Khata", icon: "📖" },
    { label: "Vahan", icon: "🛻" },
  ];
  return (
    <nav className="fixed inset-x-0 bottom-0 z-10 border-t border-border bg-card/90 backdrop-blur">
      <div className="mx-auto flex max-w-md items-end justify-around px-4 py-2">
        {items.map((it) => {
          const active = it.label === tab;
          return (
            <button
              key={it.label}
              onClick={() => onTab(it.label)}
              className={
                "flex flex-col items-center gap-0.5 rounded-full px-4 py-2 text-xs font-medium transition-transform " +
                (active ? "-translate-y-2 bg-primary text-primary-foreground shadow-lg" : "text-muted-foreground")
              }
            >
              <span className="text-base">{it.icon}</span>
              {it.label}
            </button>
          );
        })}
      </div>
    </nav>
  );
}

// ============ Load detail drawer ============
function LoadDetailDrawer({ trip, onClose }: { trip: Trip | null; onClose: () => void }) {
  const [adjustment, setAdjustment] = useState<string>("");

  useEffect(() => {
    setAdjustment("");
  }, [trip?.id]);

  useEffect(() => {
    if (!trip) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [trip, onClose]);

  const open = !!trip;
  const amount = trip?.amount ?? 0;
  const balance = trip?.balance ?? 0;
  const commission = trip?.commission ?? 0;
  const advReceived = trip?.advanceReceived ?? 0;
  const advPaid = trip?.advancePaid ?? 0;
  const adj = parseFloat(adjustment) || 0;
  // Truck's share = Amount − Commission. They already received advPaid.
  const finalPayment = amount - commission - adj - advPaid;
  const ourProfit = commission + adj + (advReceived - advPaid);

  return (
    <>
      <div
        onClick={onClose}
        className={
          "fixed inset-0 z-20 bg-foreground/40 transition-opacity " +
          (open ? "opacity-100" : "pointer-events-none opacity-0")
        }
      />
      <div
        role="dialog"
        aria-modal="true"
        className={
          "fixed inset-x-0 bottom-0 z-30 mx-auto max-w-md rounded-t-3xl border border-border bg-card shadow-2xl transition-transform duration-300 " +
          (open ? "translate-y-0" : "translate-y-full")
        }
      >
        <div className="mx-auto mt-2 h-1.5 w-10 rounded-full bg-muted" />
        {trip ? (
          <div className="max-h-[85vh] overflow-y-auto px-5 pb-6 pt-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-xs text-muted-foreground">
                  {trip.id} · {trip.party}
                </div>
                <h3 className="mt-0.5 text-lg font-bold text-foreground">{trip.truck}</h3>
                <div className="mt-1 flex items-center gap-2 text-sm text-muted-foreground">
                  <Pin className="text-primary" /> {trip.from}
                  <span>→</span>
                  <Pin className="text-emerald-500" /> {trip.to}
                </div>
                {trip.weight ? (
                  <div className="mt-1 text-xs text-muted-foreground">Weight: {kg(trip.weight)}</div>
                ) : null}
              </div>
              <StatusBadge status={trip.status} />
            </div>

            <div className="mt-5 space-y-3">
              <Row label="Freight Amount" value={inr(amount)} />
              <Row label="Advance Received (from party)" value={"+ " + inr(advReceived)} valueClass="text-emerald-600" />
              <Row label="Advance Paid (to truck)" value={"− " + inr(advPaid)} valueClass="text-destructive" />
              <Row label="Balance Due from Party" value={inr(balance)} />
              <Row label="Our Commission" value={"− " + inr(commission)} valueClass="text-destructive" />

              <div className="rounded-xl border border-border bg-[var(--app-bg)] p-3">
                <label className="block text-sm font-medium text-foreground">Commission Adjustment</label>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  Optional. Recover commission from a previous trip. Defaults to ₹0.
                </p>
                <div className="relative mt-2">
                  <span className="pointer-events-none absolute inset-y-0 left-3 flex items-center text-muted-foreground">₹</span>
                  <input
                    type="number"
                    inputMode="decimal"
                    min="0"
                    step="1"
                    value={adjustment}
                    onChange={(e) => setAdjustment(e.target.value)}
                    placeholder="0"
                    className="w-full rounded-lg border border-input bg-background py-2 pl-7 pr-3 text-sm text-foreground outline-none ring-ring focus:ring-2"
                  />
                </div>
              </div>

              <div className="rounded-xl bg-foreground p-4 text-background">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium opacity-80">Final Payment to Truck</span>
                  <span className="text-2xl font-bold">{inr(finalPayment)}</span>
                </div>
                <p className="mt-1.5 text-xs opacity-70">
                  Amount − Commission − Adjustment − Advance Paid
                </p>
                <div className="mt-3 flex items-center justify-between border-t border-background/20 pt-3">
                  <span className="text-xs opacity-80">Our Profit</span>
                  <span className="text-sm font-semibold">{inr(ourProfit)}</span>
                </div>
              </div>
            </div>

            <div className="mt-5 flex gap-2">
              <button
                onClick={onClose}
                className="flex-1 rounded-xl border border-border bg-card py-3 text-sm font-semibold text-foreground"
              >
                Close
              </button>
              <button className="flex-1 rounded-xl bg-primary py-3 text-sm font-semibold text-primary-foreground">
                Mark Paid
              </button>
            </div>
          </div>
        ) : null}
      </div>
    </>
  );
}

function Row({ label, value, valueClass = "" }: { label: string; value: string; valueClass?: string }) {
  return (
    <div className="flex items-center justify-between rounded-xl border border-border bg-card px-4 py-3">
      <span className="text-sm text-muted-foreground">{label}</span>
      <span className={"text-sm font-semibold text-foreground " + valueClass}>{value}</span>
    </div>
  );
}

// ============ New trip drawer ============
function NewTripDrawer({
  open,
  existingIds,
  trucks,
  onClose,
  onCreate,
}: {
  open: boolean;
  existingIds: string[];
  trucks: TruckMeta[];
  onClose: () => void;
  onCreate: (t: Trip) => void;
}) {
  const [truck, setTruck] = useState("");
  const [driver, setDriver] = useState("");
  const [party, setParty] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [amount, setAmount] = useState("");
  const [balance, setBalance] = useState("");
  const [commission, setCommission] = useState("");
  const [advanceReceived, setAdvanceReceived] = useState("");
  const [advancePaid, setAdvancePaid] = useState("");
  const [weight, setWeight] = useState("");
  const [status, setStatus] = useState<Status>("Loading");
  const [eta, setEta] = useState("");

  useEffect(() => {
    if (!open) return;
    setTruck(""); setDriver(""); setParty(""); setFrom(""); setTo("");
    setAmount(""); setBalance(""); setCommission(""); setWeight("");
    setAdvanceReceived(""); setAdvancePaid("");
    setStatus("Loading"); setEta("");
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  // Auto-fill driver when picking an existing truck
  useEffect(() => {
    const found = trucks.find((t) => t.truck.toLowerCase() === truck.trim().toLowerCase());
    if (found && !driver) setDriver(found.driver ?? "");
  }, [truck, trucks, driver]);

  const canSubmit = truck.trim() && party.trim() && from.trim() && to.trim() && amount;

  const nextId = () => {
    const nums = existingIds
      .map((id) => parseInt(id.replace(/[^0-9]/g, ""), 10))
      .filter((n) => !Number.isNaN(n));
    const next = (nums.length ? Math.max(...nums) : 2800) + 1;
    return `LD-${next}`;
  };

  const submit = () => {
    if (!canSubmit) return;
    const amt = parseFloat(amount) || 0;
    const advR = parseFloat(advanceReceived) || 0;
    const advP = parseFloat(advancePaid) || 0;
    const bal = balance === "" ? Math.max(amt - advR, 0) : parseFloat(balance) || 0;
    const com = parseFloat(commission) || 0;
    const wt = weight === "" ? undefined : parseFloat(weight) || 0;
    const progress = status === "Paid" ? 100 : status === "Unloading" ? 90 : status === "In-Transit" ? 50 : 5;
    onCreate({
      id: nextId(),
      truck: truck.trim().toUpperCase(),
      driver: driver.trim() || undefined,
      party: party.trim(),
      from: from.trim(),
      to: to.trim(),
      amount: amt,
      balance: bal,
      commission: com,
      advanceReceived: advR,
      advancePaid: advP,
      weight: wt,
      status,
      progress,
      eta: eta.trim() || "—",
      createdAt: Date.now(),
    });
  };

  return (
    <>
      <div
        onClick={onClose}
        className={
          "fixed inset-0 z-20 bg-foreground/40 transition-opacity " +
          (open ? "opacity-100" : "pointer-events-none opacity-0")
        }
      />
      <div
        role="dialog"
        aria-modal="true"
        className={
          "fixed inset-x-0 bottom-0 z-30 mx-auto max-w-md rounded-t-3xl border border-border bg-card shadow-2xl transition-transform duration-300 " +
          (open ? "translate-y-0" : "translate-y-full")
        }
      >
        <div className="mx-auto mt-2 h-1.5 w-10 rounded-full bg-muted" />
        <div className="max-h-[85vh] overflow-y-auto px-5 pb-6 pt-4">
          <h3 className="text-lg font-bold text-foreground">New Trip</h3>
          <p className="text-xs text-muted-foreground">
            Party is saved to Khata. Truck + driver saved to Vahan.
          </p>

          <div className="mt-4 space-y-3">
            <TextField label="Truck Number" value={truck} onChange={setTruck} placeholder="GJ01-AB-2245" list="known-trucks" />
            <datalist id="known-trucks">
              {trucks.map((t) => <option key={t.truck} value={t.truck} />)}
            </datalist>
            <TextField label="Driver" value={driver} onChange={setDriver} placeholder="Driver name" />
            <TextField label="Party (Company)" value={party} onChange={setParty} placeholder="Patel Logistics" />
            <div className="grid grid-cols-2 gap-3">
              <TextField label="From" value={from} onChange={setFrom} placeholder="Ahmedabad" />
              <TextField label="To" value={to} onChange={setTo} placeholder="Mumbai" />
            </div>
            <MoneyField label="Freight Amount" value={amount} onChange={setAmount} />
            <div className="grid grid-cols-2 gap-3">
              <MoneyField label="Advance Received" value={advanceReceived} onChange={setAdvanceReceived} hint="From party" />
              <MoneyField label="Advance Paid" value={advancePaid} onChange={setAdvancePaid} hint="To truck / driver" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <MoneyField label="Balance" value={balance} onChange={setBalance} hint="Auto: Amount − Advance" />
              <MoneyField label="Commission" value={commission} onChange={setCommission} />
            </div>
            <NumberField label="Weight (kg)" value={weight} onChange={setWeight} placeholder="e.g. 9000" />

            <div>
              <label className="text-sm font-medium text-foreground">Status</label>
              <div className="mt-1 flex flex-wrap gap-2">
                {(["Loading", "In-Transit", "Unloading", "Paid"] as Status[]).map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setStatus(s)}
                    className={
                      "rounded-full px-3 py-1.5 text-xs font-medium border " +
                      (status === s
                        ? "bg-foreground text-background border-foreground"
                        : "border-border bg-card text-muted-foreground")
                    }
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <TextField label="ETA" value={eta} onChange={setEta} placeholder="e.g. 5h" />
          </div>

          <div className="mt-5 flex gap-2">
            <button
              onClick={onClose}
              className="flex-1 rounded-xl border border-border bg-card py-3 text-sm font-semibold text-foreground"
            >
              Cancel
            </button>
            <button
              onClick={submit}
              disabled={!canSubmit}
              className="flex-1 rounded-xl bg-primary py-3 text-sm font-semibold text-primary-foreground disabled:opacity-50"
            >
              Add Trip
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

function TextField({
  label, value, onChange, placeholder, list,
}: { label: string; value: string; onChange: (v: string) => void; placeholder?: string; list?: string }) {
  return (
    <label className="block">
      <span className="text-sm font-medium text-foreground">{label}</span>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        list={list}
        className="mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground outline-none ring-ring focus:ring-2"
      />
    </label>
  );
}

function MoneyField({
  label, value, onChange, hint,
}: { label: string; value: string; onChange: (v: string) => void; hint?: string }) {
  return (
    <label className="block">
      <span className="text-sm font-medium text-foreground">{label}</span>
      <div className="relative mt-1">
        <span className="pointer-events-none absolute inset-y-0 left-3 flex items-center text-muted-foreground">₹</span>
        <input
          type="number"
          inputMode="decimal"
          min="0"
          step="1"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="0"
          className="w-full rounded-lg border border-input bg-background py-2 pl-7 pr-3 text-sm text-foreground outline-none ring-ring focus:ring-2"
        />
      </div>
      {hint ? <span className="mt-1 block text-xs text-muted-foreground">{hint}</span> : null}
    </label>
  );
}

function NumberField({
  label, value, onChange, placeholder,
}: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <label className="block">
      <span className="text-sm font-medium text-foreground">{label}</span>
      <input
        type="number"
        inputMode="decimal"
        min="0"
        step="1"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground outline-none ring-ring focus:ring-2"
      />
    </label>
  );
}
